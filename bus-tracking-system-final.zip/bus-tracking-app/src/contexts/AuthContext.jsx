import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  updateProfile
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import userService from '../services/userService';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Sign up function
  async function signup(email, password, displayName, role) {
    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, password);
      
      // Update the user's display name
      await updateProfile(user, { displayName });
      
      // Create user profile in Firestore using userService
      const userProfileData = {
        email: user.email,
        displayName: displayName,
        role: role
      };
      
      // Validate user data
      userService.validateUserData(userProfileData);
      
      const createdProfile = await userService.createUserProfile(user.uid, userProfileData);
      
      return user;
    } catch (error) {
      throw error;
    }
  }

  // Sign in function
  function signin(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  // Sign out function
  function logout() {
    return signOut(auth);
  }

  // Fetch user profile from Firestore
  async function fetchUserProfile(uid) {
    try {
      const profile = await userService.getUserProfile(uid);
      return profile;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }
  }

  // Update user profile
  async function updateUserProfile(updateData) {
    try {
      if (!currentUser) {
        throw new Error('No user logged in');
      }
      
      await userService.updateUserProfile(currentUser.uid, updateData);
      
      // Refresh user profile
      const updatedProfile = await fetchUserProfile(currentUser.uid);
      setUserProfile(updatedProfile);
      
      return true;
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }

  // Check if user is admin
  function isAdmin() {
    return userProfile?.role === 'admin' && userProfile?.isVerified;
  }

  // Check if user is driver
  function isDriver() {
    return userProfile?.role === 'driver' && userProfile?.isVerified;
  }

  // Check if user is student
  function isStudent() {
    return userProfile?.role === 'student' && userProfile?.isVerified;
  }

  // Check if user is verified
  function isVerified() {
    return userProfile?.isVerified === true;
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      
      if (user) {
        // Fetch user profile from Firestore
        const profile = await fetchUserProfile(user.uid);
        setUserProfile(profile);
        
        // If no profile exists, create one (this shouldn't happen in normal flow)
        if (!profile) {
          console.warn('User authenticated but no profile found. This may indicate a data inconsistency.');
        }
      } else {
        setUserProfile(null);
      }
      
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value = {
    currentUser,
    userProfile,
    signup,
    signin,
    logout,
    fetchUserProfile,
    updateUserProfile,
    isAdmin,
    isDriver,
    isStudent,
    isVerified
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

