import { 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  collection, 
  query, 
  where,
  orderBy,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';

class LocationService {
  constructor() {
    this.watchId = null;
    this.unsubscribe = null;
  }

  // Update driver's live location in Firestore
  async updateDriverLocation(driverId, busId, latitude, longitude, additionalData = {}) {
    try {
      const locationData = {
        driverId,
        busId,
        latitude,
        longitude,
        timestamp: serverTimestamp(),
        speed: additionalData.speed || null,
        heading: additionalData.heading || null,
        accuracy: additionalData.accuracy || null,
        lastUpdated: new Date().toISOString()
      };

      // Update the live location document
      await setDoc(doc(db, 'liveLocations', busId), locationData);
      
      console.log('Location updated successfully:', locationData);
      return true;
    } catch (error) {
      console.error('Error updating location:', error);
      throw error;
    }
  }

  // Remove driver's location when they stop tracking
  async removeDriverLocation(busId) {
    try {
      await deleteDoc(doc(db, 'liveLocations', busId));
      console.log('Location removed successfully for bus:', busId);
      return true;
    } catch (error) {
      console.error('Error removing location:', error);
      throw error;
    }
  }

  // Start watching driver's location using browser geolocation
  startLocationTracking(driverId, busId, onLocationUpdate, onError) {
    if (!navigator.geolocation) {
      const error = new Error('Geolocation is not supported by this browser.');
      onError(error);
      return;
    }

    const options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 30000 // 30 seconds
    };

    this.watchId = navigator.geolocation.watchPosition(
      async (position) => {
        try {
          const { latitude, longitude, accuracy, speed, heading } = position.coords;
          
          // Update Firebase with new location
          await this.updateDriverLocation(driverId, busId, latitude, longitude, {
            accuracy,
            speed,
            heading
          });
          
          // Call the callback with location data
          onLocationUpdate({
            latitude,
            longitude,
            accuracy,
            speed,
            heading,
            timestamp: new Date()
          });
          
        } catch (error) {
          console.error('Error in location update:', error);
          onError(error);
        }
      },
      (error) => {
        console.error('Geolocation error:', error);
        onError(error);
      },
      options
    );

    return this.watchId;
  }

  // Stop location tracking
  stopLocationTracking(busId) {
    if (this.watchId) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }

    // Remove location from Firebase
    if (busId) {
      this.removeDriverLocation(busId);
    }
  }

  // Listen to all live locations for students
  subscribeToLiveLocations(callback) {
    const q = query(
      collection(db, 'liveLocations'),
      orderBy('timestamp', 'desc')
    );

    this.unsubscribe = onSnapshot(q, (querySnapshot) => {
      const locations = [];
      querySnapshot.forEach((doc) => {
        locations.push({
          id: doc.id,
          ...doc.data()
        });
      });
      callback(locations);
    }, (error) => {
      console.error('Error listening to locations:', error);
    });

    return this.unsubscribe;
  }

  // Listen to a specific bus location
  subscribeToBusLocation(busId, callback) {
    const docRef = doc(db, 'liveLocations', busId);
    
    this.unsubscribe = onSnapshot(docRef, (doc) => {
      if (doc.exists()) {
        callback({
          id: doc.id,
          ...doc.data()
        });
      } else {
        callback(null);
      }
    }, (error) => {
      console.error('Error listening to bus location:', error);
    });

    return this.unsubscribe;
  }

  // Unsubscribe from location updates
  unsubscribeFromLocations() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
  }

  // Get current position once (for initial location)
  getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser.'));
        return;
      }

      const options = {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000 // 1 minute
      };

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude, accuracy } = position.coords;
          resolve({
            latitude,
            longitude,
            accuracy,
            timestamp: new Date()
          });
        },
        (error) => {
          reject(error);
        },
        options
      );
    });
  }

  // Calculate distance between two points (in kilometers)
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const d = R * c; // Distance in kilometers
    return d;
  }

  deg2rad(deg) {
    return deg * (Math.PI/180);
  }

  // Format location for display
  formatLocation(latitude, longitude) {
    return {
      latitude: parseFloat(latitude.toFixed(6)),
      longitude: parseFloat(longitude.toFixed(6))
    };
  }

  // Check if location is valid
  isValidLocation(latitude, longitude) {
    return (
      typeof latitude === 'number' &&
      typeof longitude === 'number' &&
      latitude >= -90 && latitude <= 90 &&
      longitude >= -180 && longitude <= 180
    );
  }
}

// Export a singleton instance
export default new LocationService();

