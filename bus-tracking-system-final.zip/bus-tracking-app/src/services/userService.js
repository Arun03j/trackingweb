import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  collection, 
  query, 
  where, 
  getDocs,
  onSnapshot,
  orderBy,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';

class UserService {
  constructor() {
    this.unsubscribe = null;
  }

  // Get user profile by ID
  async getUserProfile(userId) {
    try {
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (userDoc.exists()) {
        return {
          id: userDoc.id,
          ...userDoc.data()
        };
      }
      return null;
    } catch (error) {
      console.error('Error getting user profile:', error);
      throw error;
    }
  }

  // Create user profile
  async createUserProfile(userId, userData) {
    try {
      const userProfile = {
        ...userData,
        isVerified: false, // All users start as unverified
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      await setDoc(doc(db, 'users', userId), userProfile);
      
      return {
        id: userId,
        ...userProfile
      };
    } catch (error) {
      console.error('Error creating user profile:', error);
      throw error;
    }
  }

  // Update user profile
  async updateUserProfile(userId, updateData) {
    try {
      const updatedData = {
        ...updateData,
        updatedAt: serverTimestamp()
      };
      
      await updateDoc(doc(db, 'users', userId), updatedData);
      return true;
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }

  // Verify user (admin function)
  async verifyUser(userId, isVerified = true) {
    try {
      await this.updateUserProfile(userId, { 
        isVerified,
        verifiedAt: isVerified ? serverTimestamp() : null
      });
      return true;
    } catch (error) {
      console.error('Error verifying user:', error);
      throw error;
    }
  }

  // Delete user profile (admin function)
  async deleteUserProfile(userId) {
    try {
      await deleteDoc(doc(db, 'users', userId));
      return true;
    } catch (error) {
      console.error('Error deleting user profile:', error);
      throw error;
    }
  }

  // Get all users
  async getAllUsers() {
    try {
      const querySnapshot = await getDocs(collection(db, 'users'));
      const users = [];
      
      querySnapshot.forEach((doc) => {
        users.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return users;
    } catch (error) {
      console.error('Error getting all users:', error);
      throw error;
    }
  }

  // Get pending users (unverified)
  async getPendingUsers() {
    try {
      const q = query(
        collection(db, 'users'),
        where('isVerified', '==', false),
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      const users = [];
      
      querySnapshot.forEach((doc) => {
        users.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return users;
    } catch (error) {
      console.error('Error getting pending users:', error);
      throw error;
    }
  }

  // Get verified users
  async getVerifiedUsers() {
    try {
      const q = query(
        collection(db, 'users'),
        where('isVerified', '==', true),
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      const users = [];
      
      querySnapshot.forEach((doc) => {
        users.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return users;
    } catch (error) {
      console.error('Error getting verified users:', error);
      throw error;
    }
  }

  // Get users by role
  async getUsersByRole(role) {
    try {
      const q = query(
        collection(db, 'users'),
        where('role', '==', role),
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      const users = [];
      
      querySnapshot.forEach((doc) => {
        users.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return users;
    } catch (error) {
      console.error('Error getting users by role:', error);
      throw error;
    }
  }

  // Subscribe to all users
  subscribeToUsers(callback) {
    const q = query(
      collection(db, 'users'),
      orderBy('createdAt', 'desc')
    );
    
    this.unsubscribe = onSnapshot(q, (querySnapshot) => {
      const users = [];
      querySnapshot.forEach((doc) => {
        users.push({
          id: doc.id,
          ...doc.data()
        });
      });
      callback(users);
    }, (error) => {
      console.error('Error listening to users:', error);
    });

    return this.unsubscribe;
  }

  // Subscribe to pending users
  subscribeToPendingUsers(callback) {
    const q = query(
      collection(db, 'users'),
      where('isVerified', '==', false),
      orderBy('createdAt', 'desc')
    );
    
    this.unsubscribe = onSnapshot(q, (querySnapshot) => {
      const users = [];
      querySnapshot.forEach((doc) => {
        users.push({
          id: doc.id,
          ...doc.data()
        });
      });
      callback(users);
    }, (error) => {
      console.error('Error listening to pending users:', error);
    });

    return this.unsubscribe;
  }

  // Subscribe to a specific user
  subscribeToUser(userId, callback) {
    const docRef = doc(db, 'users', userId);
    
    this.unsubscribe = onSnapshot(docRef, (doc) => {
      if (doc.exists()) {
        callback({
          id: doc.id,
          ...doc.data()
        });
      } else {
        callback(null);
      }
    }, (error) => {
      console.error('Error listening to user:', error);
    });

    return this.unsubscribe;
  }

  // Unsubscribe from user updates
  unsubscribeFromUsers() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
  }

  // Get user statistics
  async getUserStatistics() {
    try {
      const allUsers = await this.getAllUsers();
      
      const stats = {
        total: allUsers.length,
        verified: allUsers.filter(user => user.isVerified).length,
        pending: allUsers.filter(user => !user.isVerified).length,
        students: allUsers.filter(user => user.role === 'student').length,
        drivers: allUsers.filter(user => user.role === 'driver').length,
        admins: allUsers.filter(user => user.role === 'admin').length,
        verifiedStudents: allUsers.filter(user => user.role === 'student' && user.isVerified).length,
        verifiedDrivers: allUsers.filter(user => user.role === 'driver' && user.isVerified).length
      };
      
      return stats;
    } catch (error) {
      console.error('Error getting user statistics:', error);
      throw error;
    }
  }

  // Validate user data
  validateUserData(userData) {
    const required = ['email', 'displayName', 'role'];
    const missing = required.filter(field => !userData[field]);
    
    if (missing.length > 0) {
      throw new Error(`Missing required fields: ${missing.join(', ')}`);
    }

    const validRoles = ['student', 'driver', 'admin'];
    if (!validRoles.includes(userData.role)) {
      throw new Error(`Invalid role. Must be one of: ${validRoles.join(', ')}`);
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userData.email)) {
      throw new Error('Invalid email format');
    }

    return true;
  }

  // Create default admin user (call this once to create the first admin)
  async createDefaultAdmin(adminData) {
    try {
      const defaultAdmin = {
        email: adminData.email,
        displayName: adminData.displayName || 'System Administrator',
        role: 'admin',
        isVerified: true, // Admin is automatically verified
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      await setDoc(doc(db, 'users', adminData.userId), defaultAdmin);
      
      console.log('Default admin created:', defaultAdmin);
      return {
        id: adminData.userId,
        ...defaultAdmin
      };
    } catch (error) {
      console.error('Error creating default admin:', error);
      throw error;
    }
  }

  // Batch verify multiple users
  async batchVerifyUsers(userIds, isVerified = true) {
    try {
      const promises = userIds.map(userId => 
        this.verifyUser(userId, isVerified)
      );
      
      await Promise.all(promises);
      return true;
    } catch (error) {
      console.error('Error batch verifying users:', error);
      throw error;
    }
  }

  // Search users by email or name
  async searchUsers(searchTerm) {
    try {
      const allUsers = await this.getAllUsers();
      
      const filteredUsers = allUsers.filter(user => 
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.displayName.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      return filteredUsers;
    } catch (error) {
      console.error('Error searching users:', error);
      throw error;
    }
  }
}

// Export a singleton instance
export default new UserService();

