import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs,
  onSnapshot,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';

class BusService {
  constructor() {
    this.unsubscribe = null;
  }

  // Get bus information by driver ID
  async getBusByDriverId(driverId) {
    try {
      const q = query(
        collection(db, 'buses'),
        where('driverId', '==', driverId)
      );
      
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        const doc = querySnapshot.docs[0];
        return {
          id: doc.id,
          ...doc.data()
        };
      }
      
      return null;
    } catch (error) {
      console.error('Error getting bus by driver ID:', error);
      throw error;
    }
  }

  // Get all buses
  async getAllBuses() {
    try {
      const querySnapshot = await getDocs(collection(db, 'buses'));
      const buses = [];
      
      querySnapshot.forEach((doc) => {
        buses.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return buses;
    } catch (error) {
      console.error('Error getting all buses:', error);
      throw error;
    }
  }

  // Create a new bus
  async createBus(busData) {
    try {
      const busRef = doc(collection(db, 'buses'));
      const newBus = {
        ...busData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      await setDoc(busRef, newBus);
      
      return {
        id: busRef.id,
        ...newBus
      };
    } catch (error) {
      console.error('Error creating bus:', error);
      throw error;
    }
  }

  // Update bus information
  async updateBus(busId, updateData) {
    try {
      const busRef = doc(db, 'buses', busId);
      const updatedData = {
        ...updateData,
        updatedAt: serverTimestamp()
      };
      
      await updateDoc(busRef, updatedData);
      return true;
    } catch (error) {
      console.error('Error updating bus:', error);
      throw error;
    }
  }

  // Assign driver to bus
  async assignDriverToBus(busId, driverId) {
    try {
      await this.updateBus(busId, { driverId });
      return true;
    } catch (error) {
      console.error('Error assigning driver to bus:', error);
      throw error;
    }
  }

  // Remove driver from bus
  async removeDriverFromBus(busId) {
    try {
      await this.updateBus(busId, { driverId: null });
      return true;
    } catch (error) {
      console.error('Error removing driver from bus:', error);
      throw error;
    }
  }

  // Update bus status
  async updateBusStatus(busId, status) {
    try {
      await this.updateBus(busId, { status });
      return true;
    } catch (error) {
      console.error('Error updating bus status:', error);
      throw error;
    }
  }

  // Subscribe to bus changes
  subscribeToBuses(callback) {
    const q = query(collection(db, 'buses'));
    
    this.unsubscribe = onSnapshot(q, (querySnapshot) => {
      const buses = [];
      querySnapshot.forEach((doc) => {
        buses.push({
          id: doc.id,
          ...doc.data()
        });
      });
      callback(buses);
    }, (error) => {
      console.error('Error listening to buses:', error);
    });

    return this.unsubscribe;
  }

  // Subscribe to a specific bus
  subscribeToBus(busId, callback) {
    const docRef = doc(db, 'buses', busId);
    
    this.unsubscribe = onSnapshot(docRef, (doc) => {
      if (doc.exists()) {
        callback({
          id: doc.id,
          ...doc.data()
        });
      } else {
        callback(null);
      }
    }, (error) => {
      console.error('Error listening to bus:', error);
    });

    return this.unsubscribe;
  }

  // Unsubscribe from bus updates
  unsubscribeFromBuses() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
  }

  // Get buses with their live locations
  async getBusesWithLocations() {
    try {
      const buses = await this.getAllBuses();
      const busesWithLocations = [];

      for (const bus of buses) {
        // Get live location for this bus
        const locationDoc = await getDoc(doc(db, 'liveLocations', bus.id));
        
        const busWithLocation = {
          ...bus,
          liveLocation: locationDoc.exists() ? locationDoc.data() : null
        };
        
        busesWithLocations.push(busWithLocation);
      }

      return busesWithLocations;
    } catch (error) {
      console.error('Error getting buses with locations:', error);
      throw error;
    }
  }

  // Create default buses for testing (call this once to populate the database)
  async createDefaultBuses() {
    try {
      const defaultBuses = [
        {
          busNumber: 'Route 101',
          capacity: 50,
          status: 'inactive',
          driverId: null,
          route: [
            { name: 'Main Campus Gate', latitude: 40.7128, longitude: -74.0060 },
            { name: 'Library Building', latitude: 40.7589, longitude: -73.9851 },
            { name: 'Student Center', latitude: 40.7505, longitude: -73.9934 },
            { name: 'Engineering Building', latitude: 40.7282, longitude: -74.0776 }
          ]
        },
        {
          busNumber: 'Route 102',
          capacity: 45,
          status: 'inactive',
          driverId: null,
          route: [
            { name: 'North Campus', latitude: 40.7831, longitude: -73.9712 },
            { name: 'Science Building', latitude: 40.7614, longitude: -73.9776 },
            { name: 'Arts Center', latitude: 40.7505, longitude: -73.9934 },
            { name: 'Sports Complex', latitude: 40.7282, longitude: -74.0776 }
          ]
        },
        {
          busNumber: 'Route 103',
          capacity: 40,
          status: 'maintenance',
          driverId: null,
          route: [
            { name: 'East Campus', latitude: 40.7282, longitude: -73.9942 },
            { name: 'Medical Center', latitude: 40.7831, longitude: -73.9712 },
            { name: 'Research Building', latitude: 40.7505, longitude: -73.9934 }
          ]
        }
      ];

      const createdBuses = [];
      for (const busData of defaultBuses) {
        const bus = await this.createBus(busData);
        createdBuses.push(bus);
      }

      console.log('Default buses created:', createdBuses);
      return createdBuses;
    } catch (error) {
      console.error('Error creating default buses:', error);
      throw error;
    }
  }

  // Validate bus data
  validateBusData(busData) {
    const required = ['busNumber', 'capacity'];
    const missing = required.filter(field => !busData[field]);
    
    if (missing.length > 0) {
      throw new Error(`Missing required fields: ${missing.join(', ')}`);
    }

    if (typeof busData.capacity !== 'number' || busData.capacity <= 0) {
      throw new Error('Capacity must be a positive number');
    }

    return true;
  }
}

// Export a singleton instance
export default new BusService();

