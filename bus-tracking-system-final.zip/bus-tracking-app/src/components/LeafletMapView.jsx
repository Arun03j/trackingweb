import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default markers in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

// Custom bus icon
const busIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#2563eb" width="32" height="32">
      <path d="M4 16c0 .88.39 1.67 1 2.22V20a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h8v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4v10M6.5 17.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5m11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5M5 11V6h14v5H5Z"/>
    </svg>
  `),
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32],
});

// Custom student icon
const studentIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#059669" width="24" height="24">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
    </svg>
  `),
  iconSize: [24, 24],
  iconAnchor: [12, 24],
  popupAnchor: [0, -24],
});

// Component to update map view when center changes
function ChangeView({ center, zoom }) {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  
  return null;
}

export default function LeafletMapView({ 
  busLocations = [], 
  userLocation = null, 
  showUserLocation = false,
  center = [40.7128, -74.0060], // Default to New York City
  zoom = 13,
  height = '400px',
  className = ''
}) {
  const [mapCenter, setMapCenter] = useState(center);
  const [mapZoom, setMapZoom] = useState(zoom);
  const mapRef = useRef();

  // Update map center when user location is available
  useEffect(() => {
    if (userLocation && showUserLocation) {
      setMapCenter([userLocation.latitude, userLocation.longitude]);
      setMapZoom(15);
    }
  }, [userLocation, showUserLocation]);

  // Center map on buses if available
  useEffect(() => {
    if (busLocations.length > 0 && !showUserLocation) {
      // Calculate bounds to fit all buses
      const bounds = L.latLngBounds(
        busLocations.map(bus => [bus.latitude, bus.longitude])
      );
      
      if (mapRef.current) {
        mapRef.current.fitBounds(bounds, { padding: [20, 20] });
      }
    }
  }, [busLocations, showUserLocation]);

  const formatLastUpdate = (timestamp) => {
    if (!timestamp) return 'Unknown';
    
    const now = new Date();
    const updateTime = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    const diffMs = now - updateTime;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    return updateTime.toLocaleDateString();
  };

  const getStatusColor = (isActive, lastUpdate) => {
    if (!isActive) return '#6b7280'; // Gray for inactive
    
    if (!lastUpdate) return '#ef4444'; // Red for no data
    
    const now = new Date();
    const updateTime = lastUpdate.toDate ? lastUpdate.toDate() : new Date(lastUpdate);
    const diffMs = now - updateTime;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 5) return '#10b981'; // Green for recent
    if (diffMins < 15) return '#f59e0b'; // Yellow for somewhat recent
    return '#ef4444'; // Red for old data
  };

  return (
    <div className={`relative ${className}`} style={{ height }}>
      <MapContainer
        center={mapCenter}
        zoom={mapZoom}
        style={{ height: '100%', width: '100%' }}
        ref={mapRef}
        className="rounded-lg"
      >
        <ChangeView center={mapCenter} zoom={mapZoom} />
        
        {/* OpenStreetMap tiles */}
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {/* Bus markers */}
        {busLocations.map((bus) => (
          <Marker
            key={bus.id}
            position={[bus.latitude, bus.longitude]}
            icon={busIcon}
          >
            <Popup>
              <div className="p-2 min-w-[200px]">
                <h3 className="font-semibold text-lg mb-2 flex items-center">
                  <span 
                    className="w-3 h-3 rounded-full mr-2"
                    style={{ backgroundColor: getStatusColor(bus.isActive, bus.lastUpdate) }}
                  ></span>
                  {bus.busNumber || `Bus ${bus.id}`}
                </h3>
                
                <div className="space-y-1 text-sm">
                  <p><strong>Status:</strong> {bus.isActive ? 'Active' : 'Inactive'}</p>
                  <p><strong>Driver:</strong> {bus.driverName || 'Unknown'}</p>
                  <p><strong>Last Update:</strong> {formatLastUpdate(bus.lastUpdate)}</p>
                  
                  {bus.route && bus.route.length > 0 && (
                    <div>
                      <strong>Route Stops:</strong>
                      <ul className="mt-1 ml-2">
                        {bus.route.slice(0, 3).map((stop, index) => (
                          <li key={index} className="text-xs">• {stop}</li>
                        ))}
                        {bus.route.length > 3 && (
                          <li className="text-xs text-gray-500">... and {bus.route.length - 3} more</li>
                        )}
                      </ul>
                    </div>
                  )}
                  
                  {bus.speed && (
                    <p><strong>Speed:</strong> {Math.round(bus.speed)} km/h</p>
                  )}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
        
        {/* User location marker */}
        {showUserLocation && userLocation && (
          <Marker
            position={[userLocation.latitude, userLocation.longitude]}
            icon={studentIcon}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-semibold text-lg mb-2">Your Location</h3>
                <p className="text-sm">
                  Lat: {userLocation.latitude.toFixed(6)}<br/>
                  Lng: {userLocation.longitude.toFixed(6)}
                </p>
              </div>
            </Popup>
          </Marker>
        )}
      </MapContainer>
      
      {/* Map controls overlay */}
      <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-2 z-[1000]">
        <div className="flex flex-col space-y-2">
          <button
            onClick={() => {
              if (userLocation && showUserLocation) {
                setMapCenter([userLocation.latitude, userLocation.longitude]);
                setMapZoom(15);
              }
            }}
            className="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
            disabled={!userLocation || !showUserLocation}
          >
            My Location
          </button>
          
          {busLocations.length > 0 && (
            <button
              onClick={() => {
                if (mapRef.current && busLocations.length > 0) {
                  const bounds = L.latLngBounds(
                    busLocations.map(bus => [bus.latitude, bus.longitude])
                  );
                  mapRef.current.fitBounds(bounds, { padding: [20, 20] });
                }
              }}
              className="px-3 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700"
            >
              Show All Buses
            </button>
          )}
        </div>
      </div>
      
      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 z-[1000]">
        <h4 className="font-semibold text-sm mb-2">Legend</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center">
            <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
            <span>Active (Recent)</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
            <span>Active (Delayed)</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-red-500 rounded-full mr-2"></span>
            <span>Inactive/Old Data</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-gray-500 rounded-full mr-2"></span>
            <span>Offline</span>
          </div>
        </div>
      </div>
    </div>
  );
}

