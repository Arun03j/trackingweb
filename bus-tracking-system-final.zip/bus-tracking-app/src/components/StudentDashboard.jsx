import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bus, MapPin, Clock, ArrowLeft, Navigation, RefreshCw, List } from 'lucide-react';
import locationService from '../services/locationService';
import busService from '../services/busService';
import MapView from './LeafletMapView';

export default function StudentDashboard() {
  const { currentUser, userProfile, logout } = useAuth();
  const navigate = useNavigate();
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    loadBusData();
    
    // Set up real-time listener for live locations
    const unsubscribe = locationService.subscribeToLiveLocations((locations) => {
      // Update buses with live location data
      setBuses(prevBuses => {
        return prevBuses.map(bus => {
          const liveLocation = locations.find(loc => loc.id === bus.id);
          return {
            ...bus,
            liveLocation: liveLocation || null
          };
        });
      });
      setLastUpdated(new Date());
    });

    return () => {
      unsubscribe();
    };
  }, []);

  async function loadBusData() {
    try {
      setLoading(true);
      const busData = await busService.getAllBuses();
      setBuses(busData);
    } catch (error) {
      console.error('Error loading bus data:', error);
    } finally {
      setLoading(false);
    }
  }

  function refreshBusData() {
    loadBusData();
  }

  function getStatusColor(status) {
    switch (status) {
      case 'active':
        return 'default';
      case 'inactive':
        return 'secondary';
      case 'maintenance':
        return 'destructive';
      default:
        return 'secondary';
    }
  }

  function getLastUpdatedText(lastUpdated) {
    const now = new Date();
    const diffInMinutes = Math.floor((now - lastUpdated) / (1000 * 60));
    
    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes === 1) {
      return '1 minute ago';
    } else {
      return `${diffInMinutes} minutes ago`;
    }
  }

  function isLocationRecent(locationTimestamp) {
    if (!locationTimestamp) return false;
    const now = new Date();
    const locationTime = new Date(locationTimestamp);
    const diffInMinutes = (now - locationTime) / (1000 * 60);
    return diffInMinutes <= 5; // Consider location recent if within 5 minutes
  }

  async function handleLogout() {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  }

  const activeBuses = buses.filter(bus => bus.status === 'active');
  const inactiveBuses = buses.filter(bus => bus.status !== 'active');
  const busesWithRecentLocation = buses.filter(bus => 
    bus.liveLocation && isLocationRecent(bus.liveLocation.lastUpdated)
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                onClick={() => navigate('/dashboard')}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Bus className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Student Dashboard</h1>
                <p className="text-sm text-gray-600">Track buses in real-time</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                onClick={refreshBusData}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <span className="text-sm text-gray-600">
                {userProfile?.displayName}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          
          {/* Statistics Summary */}
          <div className="mb-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Navigation className="h-5 w-5 mr-2 text-green-600" />
                  Live Bus Tracking
                </CardTitle>
                <CardDescription>
                  Real-time locations of all buses • Last updated: {getLastUpdatedText(lastUpdated)}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {activeBuses.length}
                    </div>
                    <p className="text-sm text-gray-600">Active Buses</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {busesWithRecentLocation.length}
                    </div>
                    <p className="text-sm text-gray-600">Live Tracking</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-600">
                      {inactiveBuses.length}
                    </div>
                    <p className="text-sm text-gray-600">Inactive Buses</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {buses.reduce((total, bus) => total + bus.capacity, 0)}
                    </div>
                    <p className="text-sm text-gray-600">Total Capacity</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Map and List Tabs */}
          <Tabs defaultValue="map" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="map" className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                Map View
              </TabsTrigger>
              <TabsTrigger value="list" className="flex items-center">
                <List className="h-4 w-4 mr-2" />
                List View
              </TabsTrigger>
            </TabsList>

            {/* Map View Tab */}
            <TabsContent value="map" className="space-y-4">
              <MapView 
                buses={buses} 
                onRefresh={refreshBusData} 
                loading={loading} 
              />
            </TabsContent>

            {/* List View Tab */}
            <TabsContent value="list" className="space-y-4">
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-gray-900">Available Buses</h2>
                
                {buses.length === 0 ? (
                  <Card>
                    <CardContent className="flex items-center justify-center py-12">
                      <div className="text-center">
                        <Bus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">No buses available at the moment</p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  buses.map((bus) => (
                    <Card key={bus.id} className={`${bus.status === 'active' ? 'border-green-200 bg-green-50/30' : 'border-gray-200'}`}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="flex items-center">
                              <Bus className="h-5 w-5 mr-2 text-blue-600" />
                              {bus.busNumber}
                            </CardTitle>
                            <CardDescription>
                              Capacity: {bus.capacity} passengers
                            </CardDescription>
                          </div>
                          <div className="flex flex-col items-end space-y-2">
                            <Badge variant={getStatusColor(bus.status)}>
                              {bus.status}
                            </Badge>
                            {bus.liveLocation && isLocationRecent(bus.liveLocation.lastUpdated) && (
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                Live
                              </Badge>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          
                          {/* Location */}
                          <div className="space-y-1">
                            <div className="flex items-center text-sm font-medium text-gray-700">
                              <MapPin className="h-4 w-4 mr-1" />
                              Location
                            </div>
                            {bus.liveLocation ? (
                              <div className="text-sm text-gray-600">
                                <p>Lat: {bus.liveLocation.latitude.toFixed(4)}</p>
                                <p>Lng: {bus.liveLocation.longitude.toFixed(4)}</p>
                                {bus.liveLocation.accuracy && (
                                  <p className="text-xs text-gray-500">±{Math.round(bus.liveLocation.accuracy)}m</p>
                                )}
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500">Location unavailable</p>
                            )}
                          </div>

                          {/* Route Info */}
                          <div className="space-y-1">
                            <div className="flex items-center text-sm font-medium text-gray-700">
                              <Navigation className="h-4 w-4 mr-1" />
                              Route
                            </div>
                            {bus.route && bus.route.length > 0 ? (
                              <div className="text-sm text-gray-600">
                                <p>{bus.route.length} stops</p>
                                <p className="text-xs text-gray-500">{bus.route[0]?.name}</p>
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500">Route not defined</p>
                            )}
                          </div>

                          {/* Status Details */}
                          <div className="space-y-1">
                            <div className="flex items-center text-sm font-medium text-gray-700">
                              <Clock className="h-4 w-4 mr-1" />
                              Status
                            </div>
                            <div className="text-sm text-gray-600">
                              <p className="capitalize">{bus.status}</p>
                              {bus.liveLocation && (
                                <p className="text-xs text-gray-500">
                                  {isLocationRecent(bus.liveLocation.lastUpdated) ? 'Live tracking' : 'Last seen: ' + getLastUpdatedText(new Date(bus.liveLocation.lastUpdated))}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Driver Info */}
                          <div className="space-y-1">
                            <div className="text-sm font-medium text-gray-700">
                              Driver
                            </div>
                            <div className="text-sm text-gray-600">
                              {bus.driverId ? (
                                <p>Assigned</p>
                              ) : (
                                <p className="text-gray-500">Unassigned</p>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Route Stops */}
                        {bus.route && bus.route.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-gray-200">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Route Stops</h4>
                            <div className="flex flex-wrap gap-2">
                              {bus.route.slice(0, 3).map((stop, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {stop.name}
                                </Badge>
                              ))}
                              {bus.route.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{bus.route.length - 3} more
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Last Updated */}
                        {bus.liveLocation && (
                          <div className="mt-4 pt-4 border-t border-gray-200">
                            <p className="text-xs text-gray-500">
                              Last updated: {new Date(bus.liveLocation.lastUpdated).toLocaleString()}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>

          {/* Instructions */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>How to Use</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                  <li><strong>Map View:</strong> See all active buses on an interactive map with real-time updates</li>
                  <li><strong>List View:</strong> Browse detailed information about all buses including routes and status</li>
                  <li><strong>Live Tracking:</strong> Buses with recent location updates show "Live" badge</li>
                  <li><strong>Auto Refresh:</strong> Location data updates automatically every 30 seconds</li>
                  <li><strong>Status Indicators:</strong> Green badges indicate active buses, gray for inactive</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

