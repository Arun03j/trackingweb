import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { 
  Shield, 
  Users, 
  UserCheck, 
  UserX, 
  ArrowLeft, 
  RefreshCw, 
  Search,
  CheckCircle,
  XCircle,
  Clock,
  Bus,
  AlertTriangle
} from 'lucide-react';
import userService from '../services/userService';
import busService from '../services/busService';

export default function AdminDashboard() {
  const { currentUser, userProfile, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [pendingUsers, setPendingUsers] = useState([]);
  const [buses, setBuses] = useState([]);
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);

  useEffect(() => {
    // Check if user is admin
    if (!isAdmin()) {
      navigate('/dashboard');
      return;
    }

    loadData();
    
    // Set up real-time listeners
    const unsubscribeUsers = userService.subscribeToUsers((userData) => {
      setUsers(userData);
      setFilteredUsers(userData);
    });

    const unsubscribePending = userService.subscribeToPendingUsers((pendingData) => {
      setPendingUsers(pendingData);
    });

    return () => {
      unsubscribeUsers();
      unsubscribePending();
    };
  }, [isAdmin, navigate]);

  useEffect(() => {
    // Filter users based on search term
    if (searchTerm.trim() === '') {
      setFilteredUsers(users);
    } else {
      const filtered = users.filter(user => 
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.role.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  }, [searchTerm, users]);

  async function loadData() {
    try {
      setLoading(true);
      
      // Load statistics
      const stats = await userService.getUserStatistics();
      setStatistics(stats);
      
      // Load buses
      const busData = await busService.getAllBuses();
      setBuses(busData);
      
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleVerifyUser(userId, isVerified = true) {
    try {
      await userService.verifyUser(userId, isVerified);
      console.log(`User ${userId} ${isVerified ? 'verified' : 'unverified'} successfully`);
    } catch (error) {
      console.error('Error verifying user:', error);
      alert('Failed to update user verification status. Please try again.');
    }
  }

  async function handleDeleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      return;
    }

    try {
      await userService.deleteUserProfile(userId);
      console.log(`User ${userId} deleted successfully`);
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Failed to delete user. Please try again.');
    }
  }

  async function handleBatchVerify(userIds) {
    if (!confirm(`Are you sure you want to verify ${userIds.length} users?`)) {
      return;
    }

    try {
      await userService.batchVerifyUsers(userIds, true);
      console.log(`${userIds.length} users verified successfully`);
    } catch (error) {
      console.error('Error batch verifying users:', error);
      alert('Failed to verify users. Please try again.');
    }
  }

  async function handleLogout() {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  }

  function getStatusColor(isVerified) {
    return isVerified ? 'default' : 'secondary';
  }

  function getRoleColor(role) {
    switch (role) {
      case 'admin':
        return 'destructive';
      case 'driver':
        return 'default';
      case 'student':
        return 'secondary';
      default:
        return 'secondary';
    }
  }

  if (!isAdmin()) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Access denied. You need administrator privileges to view this page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                onClick={() => navigate('/dashboard')}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Shield className="h-8 w-8 text-red-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">User verification and system management</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                onClick={loadData}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <span className="text-sm text-gray-600">
                {userProfile?.displayName}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          
          {/* Statistics Summary */}
          <div className="mb-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-blue-600" />
                  System Overview
                </CardTitle>
                <CardDescription>
                  User statistics and system status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {statistics.total || 0}
                    </div>
                    <p className="text-sm text-gray-600">Total Users</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {statistics.verified || 0}
                    </div>
                    <p className="text-sm text-gray-600">Verified</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {statistics.pending || 0}
                    </div>
                    <p className="text-sm text-gray-600">Pending</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {statistics.students || 0}
                    </div>
                    <p className="text-sm text-gray-600">Students</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-indigo-600">
                      {statistics.drivers || 0}
                    </div>
                    <p className="text-sm text-gray-600">Drivers</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-600">
                      {buses.length || 0}
                    </div>
                    <p className="text-sm text-gray-600">Buses</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Pending Verifications Alert */}
          {pendingUsers.length > 0 && (
            <Alert className="mb-6">
              <Clock className="h-4 w-4" />
              <AlertDescription>
                You have {pendingUsers.length} user{pendingUsers.length !== 1 ? 's' : ''} waiting for verification.
                <Button 
                  variant="link" 
                  className="p-0 ml-2 h-auto"
                  onClick={() => handleBatchVerify(pendingUsers.map(user => user.id))}
                >
                  Verify all pending users
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {/* User Management Tabs */}
          <Tabs defaultValue="all" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all" className="flex items-center">
                <Users className="h-4 w-4 mr-2" />
                All Users ({users.length})
              </TabsTrigger>
              <TabsTrigger value="pending" className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                Pending ({pendingUsers.length})
              </TabsTrigger>
              <TabsTrigger value="buses" className="flex items-center">
                <Bus className="h-4 w-4 mr-2" />
                Buses ({buses.length})
              </TabsTrigger>
            </TabsList>

            {/* All Users Tab */}
            <TabsContent value="all" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">All Users</h2>
                <div className="flex items-center space-x-2">
                  <Search className="h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-64"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                {filteredUsers.length === 0 ? (
                  <Card>
                    <CardContent className="flex items-center justify-center py-12">
                      <div className="text-center">
                        <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">
                          {searchTerm ? 'No users found matching your search' : 'No users found'}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  filteredUsers.map((user) => (
                    <Card key={user.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="flex items-center">
                              <Users className="h-5 w-5 mr-2 text-blue-600" />
                              {user.displayName}
                            </CardTitle>
                            <CardDescription>
                              {user.email}
                            </CardDescription>
                          </div>
                          <div className="flex flex-col items-end space-y-2">
                            <Badge variant={getRoleColor(user.role)}>
                              {user.role}
                            </Badge>
                            <Badge variant={getStatusColor(user.isVerified)}>
                              {user.isVerified ? 'Verified' : 'Pending'}
                            </Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex justify-between items-center">
                          <div className="text-sm text-gray-600">
                            <p>Created: {user.createdAt ? new Date(user.createdAt.seconds * 1000).toLocaleDateString() : 'Unknown'}</p>
                            {user.verifiedAt && (
                              <p>Verified: {new Date(user.verifiedAt.seconds * 1000).toLocaleDateString()}</p>
                            )}
                          </div>
                          <div className="flex space-x-2">
                            {!user.isVerified ? (
                              <Button 
                                size="sm" 
                                onClick={() => handleVerifyUser(user.id, true)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Verify
                              </Button>
                            ) : (
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => handleVerifyUser(user.id, false)}
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Unverify
                              </Button>
                            )}
                            {user.role !== 'admin' && (
                              <Button 
                                size="sm" 
                                variant="destructive"
                                onClick={() => handleDeleteUser(user.id)}
                              >
                                <UserX className="h-4 w-4 mr-2" />
                                Delete
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Pending Users Tab */}
            <TabsContent value="pending" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">Pending Verification</h2>
                {pendingUsers.length > 0 && (
                  <Button 
                    onClick={() => handleBatchVerify(pendingUsers.map(user => user.id))}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <UserCheck className="h-4 w-4 mr-2" />
                    Verify All ({pendingUsers.length})
                  </Button>
                )}
              </div>
              
              <div className="space-y-4">
                {pendingUsers.length === 0 ? (
                  <Card>
                    <CardContent className="flex items-center justify-center py-12">
                      <div className="text-center">
                        <UserCheck className="h-12 w-12 text-green-400 mx-auto mb-4" />
                        <p className="text-gray-600">No pending verifications</p>
                        <p className="text-sm text-gray-500 mt-2">All users are verified!</p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  pendingUsers.map((user) => (
                    <Card key={user.id} className="border-orange-200 bg-orange-50/30">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="flex items-center">
                              <Clock className="h-5 w-5 mr-2 text-orange-600" />
                              {user.displayName}
                            </CardTitle>
                            <CardDescription>
                              {user.email}
                            </CardDescription>
                          </div>
                          <Badge variant={getRoleColor(user.role)}>
                            {user.role}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex justify-between items-center">
                          <div className="text-sm text-gray-600">
                            <p>Registered: {user.createdAt ? new Date(user.createdAt.seconds * 1000).toLocaleDateString() : 'Unknown'}</p>
                            <p className="text-orange-600 font-medium">Awaiting verification</p>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleVerifyUser(user.id, true)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Verify
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleDeleteUser(user.id)}
                            >
                              <UserX className="h-4 w-4 mr-2" />
                              Reject
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Buses Tab */}
            <TabsContent value="buses" className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Bus Management</h2>
              
              <div className="space-y-4">
                {buses.length === 0 ? (
                  <Card>
                    <CardContent className="flex items-center justify-center py-12">
                      <div className="text-center">
                        <Bus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">No buses configured</p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  buses.map((bus) => (
                    <Card key={bus.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="flex items-center">
                              <Bus className="h-5 w-5 mr-2 text-blue-600" />
                              {bus.busNumber}
                            </CardTitle>
                            <CardDescription>
                              Capacity: {bus.capacity} passengers
                            </CardDescription>
                          </div>
                          <Badge variant={bus.status === 'active' ? 'default' : 'secondary'}>
                            {bus.status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-sm font-medium text-gray-700">Driver</p>
                            <p className="text-sm text-gray-600">
                              {bus.driverId ? 'Assigned' : 'Unassigned'}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-700">Route Stops</p>
                            <p className="text-sm text-gray-600">
                              {bus.route ? bus.route.length : 0} stops
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-700">Created</p>
                            <p className="text-sm text-gray-600">
                              {bus.createdAt ? new Date(bus.createdAt.seconds * 1000).toLocaleDateString() : 'Unknown'}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>

          {/* Instructions */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Administrator Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                  <li><strong>User Verification:</strong> Review and verify new user registrations to grant system access</li>
                  <li><strong>Role Management:</strong> Monitor user roles (students, drivers, admins) and their verification status</li>
                  <li><strong>Bus Oversight:</strong> View and manage bus configurations and driver assignments</li>
                  <li><strong>Batch Operations:</strong> Use "Verify All" to quickly approve multiple pending users</li>
                  <li><strong>Security:</strong> Only verified users can access their respective dashboards and features</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

