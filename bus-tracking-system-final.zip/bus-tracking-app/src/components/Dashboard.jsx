import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Bus, Users, MapPin, Settings, LogOut } from 'lucide-react';

export default function Dashboard() {
  const { currentUser, userProfile, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  }

  function handleRoleNavigation() {
    switch (userProfile?.role) {
      case 'driver':
        navigate('/driver');
        break;
      case 'student':
        navigate('/student');
        break;
      case 'admin':
        navigate('/admin');
        break;
      default:
        break;
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Bus className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Bus Tracking System</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Welcome, {userProfile?.displayName || currentUser?.email}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h2>
            <p className="text-gray-600">
              Role: <span className="font-semibold capitalize">{userProfile?.role}</span>
              {userProfile?.isVerified ? (
                <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Verified
                </span>
              ) : (
                <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                  Pending Verification
                </span>
              )}
            </p>
          </div>

          {/* Role-specific content */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userProfile?.role === 'driver' && (
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={handleRoleNavigation}>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2 text-blue-600" />
                    Driver Dashboard
                  </CardTitle>
                  <CardDescription>
                    Manage your bus location and route updates
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Enable live location tracking, update your status, and manage your assigned route.
                  </p>
                </CardContent>
              </Card>
            )}

            {userProfile?.role === 'student' && (
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={handleRoleNavigation}>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bus className="h-5 w-5 mr-2 text-green-600" />
                    Student Dashboard
                  </CardTitle>
                  <CardDescription>
                    Track your bus in real-time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    View live bus locations, estimated arrival times, and route information.
                  </p>
                </CardContent>
              </Card>
            )}

            {userProfile?.role === 'admin' && (
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={handleRoleNavigation}>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="h-5 w-5 mr-2 text-purple-600" />
                    Admin Dashboard
                  </CardTitle>
                  <CardDescription>
                    Manage users and system settings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Verify users, manage buses, and oversee the entire tracking system.
                  </p>
                </CardContent>
              </Card>
            )}

            {/* General Information Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-gray-600" />
                  Account Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <span className="text-sm font-medium text-gray-500">Email:</span>
                  <p className="text-sm text-gray-900">{currentUser?.email}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Name:</span>
                  <p className="text-sm text-gray-900">{userProfile?.displayName}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Role:</span>
                  <p className="text-sm text-gray-900 capitalize">{userProfile?.role}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Status:</span>
                  <p className="text-sm text-gray-900">
                    {userProfile?.isVerified ? 'Verified' : 'Pending Verification'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Instructions based on role */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Getting Started</CardTitle>
              </CardHeader>
              <CardContent>
                {userProfile?.role === 'driver' && (
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">As a driver, you can:</p>
                    <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                      <li>Enable live location tracking when you start your route</li>
                      <li>Update your bus status (active, inactive, maintenance)</li>
                      <li>View your assigned route and stops</li>
                    </ul>
                  </div>
                )}
                
                {userProfile?.role === 'student' && (
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">As a student, you can:</p>
                    <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                      <li>View real-time locations of all active buses</li>
                      <li>See estimated arrival times at your stop</li>
                      <li>Track your specific bus route</li>
                    </ul>
                  </div>
                )}
                
                {userProfile?.role === 'admin' && (
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">As an admin, you can:</p>
                    <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                      <li>Verify new user registrations</li>
                      <li>Manage bus information and routes</li>
                      <li>Monitor system usage and performance</li>
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

