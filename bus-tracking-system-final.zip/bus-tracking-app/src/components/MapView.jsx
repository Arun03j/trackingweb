import React, { useState, useEffect, useRef } from 'react';
import { Wrapper, Status } from '@googlemaps/react-wrapper';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, RefreshCw, AlertTriangle } from 'lucide-react';

// Google Maps API key - In a real app, this should be in environment variables
const GOOGLE_MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY_HERE';

// Map component that renders the actual Google Map
function Map({ center, zoom, buses, onBusClick }) {
  const ref = useRef(null);
  const [map, setMap] = useState(null);
  const [markers, setMarkers] = useState([]);

  useEffect(() => {
    if (ref.current && !map) {
      const newMap = new window.google.maps.Map(ref.current, {
        center,
        zoom,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
        styles: [
          {
            featureType: 'poi',
            elementType: 'labels',
            stylers: [{ visibility: 'off' }]
          }
        ]
      });
      setMap(newMap);
    }
  }, [ref, map, center, zoom]);

  useEffect(() => {
    if (map && buses) {
      // Clear existing markers
      markers.forEach(marker => marker.setMap(null));
      
      // Create new markers for each bus
      const newMarkers = buses
        .filter(bus => bus.liveLocation && bus.liveLocation.latitude && bus.liveLocation.longitude)
        .map(bus => {
          const marker = new window.google.maps.Marker({
            position: {
              lat: bus.liveLocation.latitude,
              lng: bus.liveLocation.longitude
            },
            map,
            title: bus.busNumber,
            icon: {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="20" cy="20" r="18" fill="#3B82F6" stroke="#FFFFFF" stroke-width="3"/>
                  <text x="20" y="26" text-anchor="middle" fill="white" font-family="Arial" font-size="12" font-weight="bold">🚌</text>
                </svg>
              `),
              scaledSize: new window.google.maps.Size(40, 40),
              anchor: new window.google.maps.Point(20, 20)
            }
          });

          // Add click listener
          marker.addListener('click', () => {
            onBusClick(bus);
          });

          // Add info window
          const infoWindow = new window.google.maps.InfoWindow({
            content: `
              <div style="padding: 8px; min-width: 200px;">
                <h3 style="margin: 0 0 8px 0; color: #1F2937; font-size: 16px; font-weight: bold;">${bus.busNumber}</h3>
                <p style="margin: 4px 0; color: #6B7280; font-size: 14px;">Status: <span style="color: #059669; font-weight: 500;">${bus.status}</span></p>
                <p style="margin: 4px 0; color: #6B7280; font-size: 14px;">Capacity: ${bus.capacity} passengers</p>
                <p style="margin: 4px 0; color: #6B7280; font-size: 12px;">Last updated: ${new Date(bus.liveLocation.lastUpdated).toLocaleTimeString()}</p>
              </div>
            `
          });

          marker.addListener('click', () => {
            infoWindow.open(map, marker);
          });

          return marker;
        });

      setMarkers(newMarkers);
    }
  }, [map, buses, onBusClick]);

  return <div ref={ref} style={{ width: '100%', height: '100%' }} />;
}

// Loading component
function MapLoading() {
  return (
    <div className="flex items-center justify-center h-96 bg-gray-100 rounded-lg">
      <div className="text-center">
        <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4 animate-pulse" />
        <p className="text-gray-600">Loading map...</p>
      </div>
    </div>
  );
}

// Error component
function MapError({ error }) {
  return (
    <Alert variant="destructive">
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription>
        Failed to load map: {error}. Please check your internet connection and try again.
      </AlertDescription>
    </Alert>
  );
}

// Main MapView component
export default function MapView({ buses, onRefresh, loading }) {
  const [selectedBus, setSelectedBus] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: 40.7128, lng: -74.0060 }); // Default to NYC
  const [mapZoom, setMapZoom] = useState(12);

  // Update map center when buses change
  useEffect(() => {
    if (buses && buses.length > 0) {
      const activeBuses = buses.filter(bus => 
        bus.liveLocation && 
        bus.liveLocation.latitude && 
        bus.liveLocation.longitude
      );
      
      if (activeBuses.length > 0) {
        // Calculate center point of all active buses
        const avgLat = activeBuses.reduce((sum, bus) => sum + bus.liveLocation.latitude, 0) / activeBuses.length;
        const avgLng = activeBuses.reduce((sum, bus) => sum + bus.liveLocation.longitude, 0) / activeBuses.length;
        
        setMapCenter({ lat: avgLat, lng: avgLng });
      }
    }
  }, [buses]);

  function handleBusClick(bus) {
    setSelectedBus(bus);
    if (bus.liveLocation) {
      setMapCenter({
        lat: bus.liveLocation.latitude,
        lng: bus.liveLocation.longitude
      });
      setMapZoom(15);
    }
  }

  function resetMapView() {
    setSelectedBus(null);
    setMapZoom(12);
    
    // Recalculate center
    if (buses && buses.length > 0) {
      const activeBuses = buses.filter(bus => 
        bus.liveLocation && 
        bus.liveLocation.latitude && 
        bus.liveLocation.longitude
      );
      
      if (activeBuses.length > 0) {
        const avgLat = activeBuses.reduce((sum, bus) => sum + bus.liveLocation.latitude, 0) / activeBuses.length;
        const avgLng = activeBuses.reduce((sum, bus) => sum + bus.liveLocation.longitude, 0) / activeBuses.length;
        setMapCenter({ lat: avgLat, lng: avgLng });
      }
    }
  }

  const render = (status) => {
    switch (status) {
      case Status.LOADING:
        return <MapLoading />;
      case Status.FAILURE:
        return <MapError error="Google Maps failed to load" />;
      case Status.SUCCESS:
        return (
          <Map
            center={mapCenter}
            zoom={mapZoom}
            buses={buses}
            onBusClick={handleBusClick}
          />
        );
      default:
        return <MapLoading />;
    }
  };

  // Check if Google Maps API key is configured
  if (!GOOGLE_MAPS_API_KEY || GOOGLE_MAPS_API_KEY === 'YOUR_GOOGLE_MAPS_API_KEY_HERE') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-red-600" />
            Map Configuration Required
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Google Maps API key is not configured. Please add your API key to enable map functionality.
              <br />
              <br />
              <strong>For demonstration purposes, here's a mock map view:</strong>
            </AlertDescription>
          </Alert>
          
          {/* Mock map view */}
          <div className="mt-4 h-96 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 opacity-20">
              <div className="grid grid-cols-8 grid-rows-6 h-full">
                {Array.from({ length: 48 }).map((_, i) => (
                  <div key={i} className="border border-gray-300"></div>
                ))}
              </div>
            </div>
            
            <div className="relative z-10 text-center">
              <MapPin className="h-16 w-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">Bus Tracking Map</h3>
              <p className="text-gray-600 mb-4">Live bus locations would appear here</p>
              
              {/* Mock bus markers */}
              <div className="flex justify-center space-x-8">
                {buses?.filter(bus => bus.status === 'active').slice(0, 3).map((bus, index) => (
                  <div key={bus.id} className="text-center">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold mb-1">
                      🚌
                    </div>
                    <p className="text-xs text-gray-600">{bus.busNumber}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Map Controls */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h3 className="text-lg font-semibold">Live Bus Locations</h3>
          {selectedBus && (
            <Badge variant="outline">
              Viewing: {selectedBus.busNumber}
            </Badge>
          )}
        </div>
        <div className="flex space-x-2">
          {selectedBus && (
            <Button variant="outline" size="sm" onClick={resetMapView}>
              <Navigation className="h-4 w-4 mr-2" />
              Show All
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={onRefresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Map Container */}
      <Card>
        <CardContent className="p-0">
          <div className="h-96 rounded-lg overflow-hidden">
            <Wrapper apiKey={GOOGLE_MAPS_API_KEY} render={render} />
          </div>
        </CardContent>
      </Card>

      {/* Selected Bus Info */}
      {selectedBus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-blue-600" />
              {selectedBus.busNumber} Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Status</p>
                <Badge variant={selectedBus.status === 'active' ? 'default' : 'secondary'}>
                  {selectedBus.status}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Capacity</p>
                <p className="text-sm text-gray-900">{selectedBus.capacity} passengers</p>
              </div>
              {selectedBus.liveLocation && (
                <>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Latitude</p>
                    <p className="text-sm text-gray-900">{selectedBus.liveLocation.latitude.toFixed(6)}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Longitude</p>
                    <p className="text-sm text-gray-900">{selectedBus.liveLocation.longitude.toFixed(6)}</p>
                  </div>
                </>
              )}
            </div>
            
            {selectedBus.liveLocation && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-xs text-gray-500">
                  Last updated: {new Date(selectedBus.liveLocation.lastUpdated).toLocaleString()}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

