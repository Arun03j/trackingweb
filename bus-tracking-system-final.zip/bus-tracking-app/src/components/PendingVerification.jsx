import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Clock, 
  Mail, 
  Shield, 
  CheckCircle, 
  AlertTriangle,
  LogOut,
  RefreshCw
} from 'lucide-react';

export default function PendingVerification() {
  const { currentUser, userProfile, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  }

  function handleRefresh() {
    window.location.reload();
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        
        {/* Main Status Card */}
        <Card className="text-center">
          <CardHeader className="pb-4">
            <div className="mx-auto w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
            <CardTitle className="text-xl font-semibold text-gray-900">
              Account Pending Verification
            </CardTitle>
            <CardDescription className="text-gray-600">
              Your account is waiting for administrator approval
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {/* User Info */}
            <div className="bg-gray-50 rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-center space-x-2">
                <Mail className="h-4 w-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">
                  {currentUser?.email}
                </span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <Shield className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-600 capitalize">
                  {userProfile?.role || 'User'} Account
                </span>
              </div>
            </div>

            {/* Status Alert */}
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Your account registration was successful, but you need administrator approval before accessing the system.
              </AlertDescription>
            </Alert>

            {/* What happens next */}
            <div className="text-left space-y-3">
              <h3 className="font-medium text-gray-900">What happens next?</h3>
              <div className="space-y-2">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">1</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    An administrator will review your account details
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">2</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    You'll receive approval to access the bus tracking system
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                  </div>
                  <p className="text-sm text-gray-600">
                    You can then log in and use all features
                  </p>
                </div>
              </div>
            </div>

            {/* Expected timeline */}
            <div className="bg-blue-50 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                <strong>Expected Timeline:</strong> Account verification typically takes 1-2 business days.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="space-y-3">
          <Button 
            onClick={handleRefresh}
            className="w-full"
            variant="outline"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Check Verification Status
          </Button>
          
          <Button 
            onClick={handleLogout}
            className="w-full"
            variant="secondary"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>

        {/* Help Section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Need Help?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm text-gray-600">
              If you have questions about your account verification or need immediate assistance:
            </p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Contact your system administrator</li>
              <li>• Check your email for updates</li>
              <li>• Ensure you selected the correct role during registration</li>
            </ul>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center">
          <p className="text-xs text-gray-500">
            Bus Tracking System - Secure Access Control
          </p>
        </div>
      </div>
    </div>
  );
}

