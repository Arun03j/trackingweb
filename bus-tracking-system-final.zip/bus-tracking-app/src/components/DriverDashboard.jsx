import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Bus, MapPin, Navigation, ArrowLeft, Clock, Users, AlertTriangle } from 'lucide-react';
import locationService from '../services/locationService';
import busService from '../services/busService';

export default function DriverDashboard() {
  const { currentUser, userProfile, logout } = useAuth();
  const navigate = useNavigate();
  const [locationEnabled, setLocationEnabled] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [locationError, setLocationError] = useState('');
  const [busInfo, setBusInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDriverBus();
    
    // Cleanup on unmount
    return () => {
      if (locationEnabled) {
        handleLocationToggle(false);
      }
    };
  }, [currentUser]);

  async function loadDriverBus() {
    try {
      setLoading(true);
      const bus = await busService.getBusByDriverId(currentUser.uid);
      
      if (bus) {
        setBusInfo(bus);
      } else {
        // Create a default bus assignment for this driver
        const defaultBus = {
          busNumber: `Route ${Math.floor(Math.random() * 900) + 100}`,
          capacity: 50,
          status: 'inactive',
          driverId: currentUser.uid,
          route: [
            { name: 'Main Campus Gate', latitude: 40.7128, longitude: -74.0060 },
            { name: 'Library Building', latitude: 40.7589, longitude: -73.9851 },
            { name: 'Student Center', latitude: 40.7505, longitude: -73.9934 }
          ]
        };
        
        const createdBus = await busService.createBus(defaultBus);
        setBusInfo(createdBus);
      }
    } catch (error) {
      console.error('Error loading driver bus:', error);
      setLocationError('Failed to load bus information. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function handleLocationToggle(enabled) {
    if (enabled) {
      startLocationTracking();
    } else {
      stopLocationTracking();
    }
  }

  function startLocationTracking() {
    if (!busInfo) {
      setLocationError('Bus information not available. Please refresh the page.');
      return;
    }

    setLocationError('');
    
    locationService.startLocationTracking(
      currentUser.uid,
      busInfo.id,
      (location) => {
        setCurrentLocation(location);
        setLocationEnabled(true);
        
        // Update bus status to active when location tracking starts
        if (busInfo.status !== 'active') {
          busService.updateBusStatus(busInfo.id, 'active');
          setBusInfo(prev => ({ ...prev, status: 'active' }));
        }
      },
      (error) => {
        setLocationError(`Location error: ${error.message}`);
        setLocationEnabled(false);
        setCurrentLocation(null);
      }
    );
  }

  function stopLocationTracking() {
    locationService.stopLocationTracking(busInfo?.id);
    setLocationEnabled(false);
    setCurrentLocation(null);
    setLocationError('');
    
    // Update bus status to inactive when location tracking stops
    if (busInfo && busInfo.status === 'active') {
      busService.updateBusStatus(busInfo.id, 'inactive');
      setBusInfo(prev => ({ ...prev, status: 'inactive' }));
    }
  }

  async function handleLogout() {
    try {
      if (locationEnabled) {
        stopLocationTracking();
      }
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Bus className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading your bus information...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                onClick={() => navigate('/dashboard')}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Bus className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Driver Dashboard</h1>
                <p className="text-sm text-gray-600">{busInfo?.busNumber || 'Loading...'}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                {userProfile?.displayName}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          
          {/* Bus Assignment Check */}
          {!busInfo && (
            <Alert variant="destructive" className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                No bus assigned to your account. Please contact an administrator.
              </AlertDescription>
            </Alert>
          )}

          {busInfo && (
            <>
              {/* Location Tracking Control */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Navigation className="h-5 w-5 mr-2 text-blue-600" />
                    Live Location Tracking
                  </CardTitle>
                  <CardDescription>
                    Enable location sharing to allow students to track your bus
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">
                        Location Sharing: {locationEnabled ? 'Enabled' : 'Disabled'}
                      </p>
                      {currentLocation && (
                        <div className="text-xs text-gray-500 space-y-1">
                          <p>Lat: {currentLocation.latitude.toFixed(6)}</p>
                          <p>Lng: {currentLocation.longitude.toFixed(6)}</p>
                          {currentLocation.accuracy && (
                            <p>Accuracy: ±{Math.round(currentLocation.accuracy)}m</p>
                          )}
                          <p>Last updated: {currentLocation.timestamp.toLocaleTimeString()}</p>
                        </div>
                      )}
                    </div>
                    <Switch
                      checked={locationEnabled}
                      onCheckedChange={handleLocationToggle}
                    />
                  </div>
                  
                  {locationError && (
                    <Alert variant="destructive" className="mt-4">
                      <AlertDescription>{locationError}</AlertDescription>
                    </Alert>
                  )}
                  
                  {locationEnabled && (
                    <Alert className="mt-4">
                      <MapPin className="h-4 w-4" />
                      <AlertDescription>
                        Your location is being shared with students. They can now track your bus in real-time.
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>

              {/* Bus Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Bus Route</CardTitle>
                    <Bus className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{busInfo.busNumber}</div>
                    <p className="text-xs text-muted-foreground">
                      Your assigned route
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Capacity</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{busInfo.capacity}</div>
                    <p className="text-xs text-muted-foreground">
                      Maximum passengers
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Status</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <Badge variant={busInfo.status === 'active' ? 'default' : 'secondary'}>
                      {busInfo.status}
                    </Badge>
                    <p className="text-xs text-muted-foreground mt-1">
                      Current bus status
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Tracking</CardTitle>
                    <Navigation className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <Badge variant={locationEnabled ? 'default' : 'secondary'}>
                      {locationEnabled ? 'Live' : 'Offline'}
                    </Badge>
                    <p className="text-xs text-muted-foreground mt-1">
                      Location sharing
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Route Information */}
              {busInfo.route && busInfo.route.length > 0 && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Route Stops</CardTitle>
                    <CardDescription>
                      Your assigned route with all stops
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {busInfo.route.map((stop, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <div className="flex-shrink-0">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                            </div>
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">{stop.name}</p>
                            <p className="text-xs text-gray-500">
                              {stop.latitude.toFixed(4)}, {stop.longitude.toFixed(4)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Instructions */}
              <Card>
                <CardHeader>
                  <CardTitle>Driver Instructions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Important Notes:</h4>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        <li>Enable location tracking when you start your route</li>
                        <li>Keep the app open and your device connected to ensure continuous tracking</li>
                        <li>Disable location tracking when you finish your route or take a break</li>
                        <li>Students will only see your location when tracking is enabled</li>
                        <li>Your bus status will automatically update based on tracking state</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Privacy:</strong> Your location is only shared when you explicitly enable tracking. 
                        You have full control over when students can see your bus location.
                      </p>
                    </div>

                    {currentLocation && (
                      <div className="p-4 bg-green-50 rounded-lg">
                        <p className="text-sm text-green-800">
                          <strong>Active Tracking:</strong> Your location is being updated every 30 seconds. 
                          Students can see your current position and track your progress.
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}

