# Bus Tracking System - Setup Guide (Open Source Edition)

This guide will walk you through setting up the bus tracking system with **Leaflet + OpenStreetMap** - completely free and no API keys required!

## 📋 Prerequisites Checklist

Before you begin, make sure you have:

- [ ] Node.js (version 18 or higher) installed
- [ ] A Google account for Firebase
- [ ] Basic knowledge of web development
- [ ] ✅ **No Google Maps API key needed!** (Major improvement!)

## 🔥 Step 1: Firebase Project Setup

### 1.1 Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project"
3. Enter project name: `bus-tracking-system`
4. Enable Google Analytics (optional)
5. Click "Create project"

### 1.2 Enable Authentication

1. In Firebase Console, go to "Authentication"
2. Click "Get started"
3. Go to "Sign-in method" tab
4. Enable "Email/Password" provider
5. Save changes

### 1.3 Create Firestore Database

1. Go to "Firestore Database"
2. Click "Create database"
3. Choose "Start in test mode" (we'll add security rules later)
4. Select a location close to your users
5. Click "Done"

### 1.4 Get Firebase Configuration

1. Go to Project Settings (gear icon)
2. Scroll down to "Your apps"
3. Click "Web" icon (</>) to add a web app
4. Enter app nickname: `bus-tracking-web`
5. Copy the configuration object

## 💻 Step 2: Application Setup

### 2.1 Download Project Files

Download all the project files to your local machine:

```
bus-tracking-app/
├── src/
├── public/
├── package.json
├── vite.config.js
└── ... (other files)
```

### 2.2 Install Dependencies

Open terminal in the project directory and run:

```bash
cd bus-tracking-app
npm install
```

**Note**: The application now uses Leaflet instead of Google Maps, so no additional API setup is required!

### 2.3 Configure Firebase

Edit `src/lib/firebase.js` and replace the configuration:

```javascript
// Replace this configuration with your Firebase project config
const firebaseConfig = {
  apiKey: "your-api-key-here",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id"
};
```

## 🔒 Step 3: Security Rules Setup

### 3.1 Firestore Security Rules

1. Go to Firebase Console > Firestore Database
2. Click "Rules" tab
3. Replace the rules with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users collection
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    // Live locations collection
    match /liveLocations/{busId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'driver';
    }
    
    // Buses collection
    match /buses/{busId} {
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isVerified == true;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
  }
}
```

4. Click "Publish"

## 🚀 Step 4: First Run

### 4.1 Start Development Server

```bash
npm run dev
```

The application will be available at `http://localhost:5173`

### 4.2 Create First Admin User

1. Open the application in your browser
2. Click "Sign up here"
3. Fill in the form:
   - Full Name: Your name
   - Email: Your email
   - Role: Select "Student" (we'll change this manually)
   - Password: Your password
4. Click "Create Account"

### 4.3 Make User Admin (Manual Step)

Since the first user needs to be an admin, you'll need to manually update this in Firebase:

1. Go to Firebase Console > Firestore Database
2. Find the "users" collection
3. Click on your user document
4. Edit the document:
   - Change `role` from "student" to "admin"
   - Change `isVerified` from `false` to `true`
5. Save changes

### 4.4 Test Admin Access

1. Refresh the application
2. Log in with your credentials
3. You should now see "Admin Dashboard" option
4. You can now verify other users who register

## 🧪 Step 5: Testing the System

### 5.1 Test User Registration

1. Open an incognito/private browser window
2. Register a new user as "Student"
3. In your admin account, verify this user
4. Test student dashboard access

### 5.2 Test Driver Functionality

1. Register another user as "Driver"
2. Verify them as admin
3. Test location sharing functionality
4. Check if location appears on student map

### 5.3 Test Map Functionality

1. Ensure Leaflet maps load correctly (they should work immediately!)
2. Test location markers
3. Verify real-time updates
4. Test map controls and interactions

## 🗺️ Step 6: Understanding the New Map System

### 6.1 Leaflet + OpenStreetMap Benefits

- **Completely Free**: No API keys, no billing, no usage limits
- **Better Performance**: Lightweight (42KB) and fast loading
- **Enhanced Privacy**: No tracking by Google
- **Full Customization**: Complete control over map styling
- **Mobile Optimized**: Touch-friendly controls

### 6.2 Map Features

- **Interactive Maps**: Pan, zoom, and click interactions
- **Custom Markers**: Bus and student location icons
- **Real-time Updates**: Live location tracking
- **Status Indicators**: Color-coded bus status
- **Distance Calculation**: Shows distance to buses
- **Map Controls**: Center on location, show all buses
- **Responsive Design**: Works on all devices

## 🌐 Step 7: Production Deployment

### 7.1 Build for Production

```bash
npm run build
```

### 7.2 Deploy to Hosting Service

You can deploy to various services:

- **Firebase Hosting**: `firebase deploy`
- **Netlify**: Drag and drop the `dist` folder
- **Vercel**: Connect your GitHub repository
- **Traditional hosting**: Upload `dist` folder contents

### 7.3 Update Firebase Configuration

For production, update your Firebase project settings:

1. Add your production domain to authorized domains
2. Update CORS settings if needed
3. Review security rules for production use

## 🔧 Troubleshooting

### Common Issues

1. **"Firebase not configured"**
   - Check `src/lib/firebase.js` configuration
   - Ensure all Firebase services are enabled

2. **"Maps not loading"**
   - Check internet connection
   - Verify Leaflet CSS is imported correctly
   - Check browser console for errors

3. **"Location not working"**
   - Check browser permissions for geolocation
   - Ensure HTTPS in production (required for geolocation)

4. **"User not verified"**
   - Check admin dashboard for pending users
   - Verify Firestore security rules are correct

### Performance Tips

- Maps load faster without Google API calls
- Location updates are optimized for battery life
- Real-time listeners are automatically cleaned up
- Leaflet provides smooth animations and interactions

## ✅ Final Checklist

Before going live, ensure:

- [ ] Firebase configuration is correct
- [ ] Security rules are in place
- [ ] First admin user is created
- [ ] Application builds without errors
- [ ] Maps load and function correctly
- [ ] All features tested and working
- [ ] Production domain configured in Firebase

## 🎉 Congratulations!

Your bus tracking system is now ready to use with completely free and open-source mapping! 

## 🆕 What's Different from Google Maps Version

### ✅ Improvements
- **No API Keys**: No Google Maps API key required
- **No Costs**: Completely free, no usage limits
- **Better Privacy**: No tracking by Google
- **Faster Loading**: Optimized performance
- **Full Control**: Complete customization possible

### ✅ Same Features
- Real-time bus tracking
- Interactive maps
- Custom markers and popups
- Mobile optimization
- All user management features

### 📞 Support

For technical support or questions about the setup process, refer to the main README.md file or check the official documentation for Firebase and Leaflet.

---

**Enjoy your free, open-source bus tracking system! 🚌🗺️**

