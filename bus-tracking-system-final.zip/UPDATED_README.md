# Bus Tracking System - Open Source Edition

A comprehensive real-time bus tracking website built with React, Firebase, and **Leaflet + OpenStreetMap** - completely free and open source!

## 🚀 Live Demo

**Latest Deployment**: https://wufsywwu.manus.space

## ✨ Features

### 🔐 Role-Based Authentication
- **Students**: Can view live bus locations and track routes
- **Drivers**: Can share their live location and manage bus status
- **Admins**: Can verify users and manage the system

### 📍 Live Location Tracking
- Real-time GPS tracking for drivers
- Automatic location updates every 30 seconds
- Privacy controls for drivers to enable/disable sharing

### 🗺️ Interactive Map Visualization
- **Leaflet + OpenStreetMap** integration (completely free!)
- Real-time bus markers with status information
- Custom bus and student location icons
- Interactive popups with detailed information
- Map controls and status legend
- Distance calculations from user location

### 👥 User Verification System
- Admin dashboard for user management
- Pending user verification workflow
- Batch verification capabilities
- Role-based access control

### 📱 Responsive Design
- Mobile-friendly interface
- Modern UI with shadcn/ui components
- Professional design with consistent branding
- Touch-optimized map controls

## 🛠️ Technology Stack

- **Frontend**: React 18 with Vite
- **UI Framework**: shadcn/ui + Tailwind CSS
- **Authentication**: Firebase Auth
- **Database**: Firebase Firestore
- **Maps**: Leaflet + OpenStreetMap (FREE!)
- **Icons**: Lucide React + Custom SVG
- **Routing**: React Router
- **State Management**: React Context API

## 🆓 Why Open Source Maps?

### Benefits of Leaflet + OpenStreetMap
- **Completely Free**: No API keys, no usage limits, no billing
- **Lightweight**: Only 42KB core library
- **Privacy-Friendly**: No tracking by Google
- **Highly Customizable**: Full control over styling and features
- **Better Performance**: Optimized for mobile and desktop
- **Open Source**: Community-driven, transparent
- **Reliable**: Used by major organizations worldwide

### Comparison with Google Maps

| Feature | Google Maps | Leaflet + OpenStreetMap |
|---------|-------------|-------------------------|
| **Cost** | Requires API key + billing | Completely free |
| **Setup Complexity** | API key configuration | No configuration needed |
| **Usage Limits** | Yes (billing-based) | None |
| **Bundle Size** | Larger | Smaller (42KB core) |
| **Privacy** | Google tracking | No tracking |
| **Customization** | Limited | Full control |
| **Performance** | Good | Excellent |
| **Mobile Support** | Good | Optimized |

## 📋 Prerequisites

Before setting up the application, ensure you have:

1. **Node.js** (version 18 or higher)
2. **Firebase Project** with Authentication and Firestore enabled
3. **No Google Maps API Key needed!** 🎉

## ⚙️ Configuration

### 1. Firebase Setup

1. Create a new Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Enable Authentication with Email/Password provider
3. Enable Firestore Database
4. Get your Firebase configuration from Project Settings

Replace the configuration in `src/lib/firebase.js`:

```javascript
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id"
};
```

### 2. Firestore Security Rules

Set up the following security rules in Firebase Console:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own profile
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    // Live locations - drivers can write, students can read
    match /liveLocations/{busId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'driver';
    }
    
    // Buses - admins can write, verified users can read
    match /buses/{busId} {
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isVerified == true;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
  }
}
```

## 🚀 Installation & Setup

1. **Clone or download the project files**

2. **Install dependencies**:
   ```bash
   cd bus-tracking-app
   npm install
   ```

3. **Configure Firebase** (see Configuration section above)

4. **Start development server**:
   ```bash
   npm run dev
   ```

5. **Build for production**:
   ```bash
   npm run build
   ```

## 👤 User Roles & Workflows

### For Students
1. Register with email and select "Student" role
2. Wait for admin verification
3. Once verified, access the Student Dashboard
4. View live bus locations on interactive map
5. Track buses in real-time with distance information

### For Drivers
1. Register with email and select "Driver" role
2. Wait for admin verification
3. Once verified, access the Driver Dashboard
4. Enable location sharing when starting route
5. Manage bus status and route information

### For Administrators
1. First admin must be created manually in Firebase
2. Access Admin Dashboard to verify new users
3. Manage user roles and permissions
4. Monitor system usage and bus assignments

## 🗺️ Map Features

### Interactive Leaflet Map
- **OpenStreetMap Tiles**: High-quality, free map tiles
- **Custom Markers**: Bus and student location icons
- **Real-time Updates**: Live location tracking
- **Interactive Popups**: Detailed bus information
- **Map Controls**: Center on location, show all buses
- **Status Legend**: Color-coded bus status indicators
- **Distance Calculation**: Shows distance to buses
- **Responsive Design**: Optimized for all devices

### Status Indicators
- 🟢 **Green**: Active and recent (< 5 minutes)
- 🟡 **Yellow**: Active but delayed (5-15 minutes)
- 🔴 **Red**: Inactive or stale data (> 15 minutes)
- ⚫ **Gray**: Offline

## 📱 Application Structure

```
src/
├── components/           # React components
│   ├── Login.jsx        # Login form
│   ├── Register.jsx     # Registration form
│   ├── Dashboard.jsx    # Main dashboard
│   ├── StudentDashboard.jsx    # Student interface
│   ├── DriverDashboard.jsx     # Driver interface
│   ├── AdminDashboard.jsx      # Admin interface
│   └── LeafletMapView.jsx      # Leaflet map component
├── contexts/            # React contexts
│   └── AuthContext.jsx  # Authentication state
├── services/            # Business logic
│   ├── userService.js   # User management
│   ├── busService.js    # Bus operations
│   └── locationService.js # Location tracking
├── lib/                 # Configuration
│   └── firebase.js      # Firebase setup
└── App.jsx             # Main app component
```

## 🔧 Key Features Implementation

### Real-Time Location Tracking
- Uses browser Geolocation API
- Updates Firebase every 30 seconds
- Automatic cleanup when tracking stops

### User Verification System
- Admin approval required for all new users
- Role-based access control
- Batch verification capabilities

### Leaflet Map Integration
- OpenStreetMap with custom bus markers
- Real-time location updates
- Interactive popups and controls
- Mobile-optimized touch controls

### Responsive Design
- Mobile-first approach
- Touch-friendly interface
- Professional UI components

## 🛡️ Security Features

- Firebase Authentication for secure login
- Role-based access control
- Firestore security rules
- Input validation and sanitization
- Privacy controls for location sharing

## 📞 Support & Maintenance

### Common Issues

1. **Firebase Connection**: Ensure correct configuration in `firebase.js`
2. **Maps Not Loading**: Check internet connection and Leaflet CSS import
3. **Location Not Working**: Check browser permissions for geolocation
4. **User Not Verified**: Contact admin for account verification

### Performance Optimization

- Real-time listeners are automatically cleaned up
- Location updates are throttled to prevent excessive API calls
- Efficient state management with React Context
- Optimized Leaflet rendering for smooth performance

## 🎉 What's New in Open Source Edition

### ✅ Removed Dependencies
- ❌ Google Maps API (no longer needed)
- ❌ API key requirements
- ❌ Usage limits and billing concerns

### ✅ Added Features
- ✅ Leaflet + OpenStreetMap integration
- ✅ Custom SVG icons for buses and students
- ✅ Enhanced map controls and legend
- ✅ Better mobile optimization
- ✅ Improved performance and privacy

### ✅ Benefits
- 🆓 **Completely Free**: No costs, no limits
- 🚀 **Better Performance**: Faster loading, smoother interactions
- 🔒 **Enhanced Privacy**: No external tracking
- 🎨 **Full Customization**: Complete control over map styling
- 📱 **Mobile Optimized**: Touch-friendly controls

## 📄 License

This project is created for educational and demonstration purposes.

## 🤝 Contributing

This is a complete, production-ready bus tracking system. For customizations or additional features, modify the source code according to your specific requirements.

---

**Built with ❤️ using React, Firebase, Leaflet, and modern web technologies**

**Now 100% free and open source! 🎉**

